import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {HttpClientModule} from '@angular/common/http';
import {getCompanyService} from './services/getCompany.service';
import { GetcompaniesComponent } from './getcompanies/getcompanies.component';
import { AddcompanyComponent } from './addcompany/addcompany.component';
import { UpdatecompanyComponent } from './updatecompany/updatecompany.component';
import { getOneCompanyService } from './services/getOneCompany.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
//import { FormGroup, FormArray, Validators } from '@angular/forms';
import { updateCompanyService } from './services/updateCompany.service';
import { addCompanyService } from './services/addCompany.service';
import { deleteCompanyService } from './services/deleteCompany.service';
@NgModule({
  declarations: [
    AppComponent,
    GetcompaniesComponent,
    AddcompanyComponent,
    UpdatecompanyComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [getCompanyService,getOneCompanyService,updateCompanyService,addCompanyService,deleteCompanyService],
  bootstrap: [AppComponent]
})
export class AppModule { }
