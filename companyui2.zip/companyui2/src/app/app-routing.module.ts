import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UpdatecompanyComponent } from './updatecompany/updatecompany.component';
import { GetcompaniesComponent } from './getcompanies/getcompanies.component';
import { AddcompanyComponent } from './addcompany/addcompany.component';

const routes: Routes = [
  { path: 'update/:companyId', component: UpdatecompanyComponent },
  { path: 'getCompanies', component: GetcompaniesComponent },
  { path: 'addCompany', component: AddcompanyComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
