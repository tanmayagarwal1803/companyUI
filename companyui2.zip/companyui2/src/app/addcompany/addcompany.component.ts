import { Component, OnInit } from '@angular/core';
import {Companies} from '../classes/companies';
import{addCompanyService} from '../services/addCompany.service';
//import { FormGroup, FormControl, FormArray, Validators } from '@angular/forms';
import { FormBuilder } from '@angular/forms';
import {Router} from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
@Component({
  selector: 'app-addcompany',
  templateUrl: './addcompany.component.html',
  styleUrls: ['./addcompany.component.css']
})
export class AddcompanyComponent implements OnInit {
  objpost:Companies;
  company:Companies;
  constructor(private addcompanyservice:addCompanyService,private _router: Router) {
    this.company=new Companies();
   }
  
  
 // postdata.assocStockExchange={}????form;
 
 ngOnInit()
{
  //var postdata=new Companies();
 // postdata.companyId=this.addCompanyForm.get('companyid').value;
  //postdata.companyName=this.addCompanyForm.get('companyname').value;
  //postdata.companyCode=this.addCompanyForm.get('companycode').value;
  //postdata.ceo=this.addCompanyForm.get('companyceo').value;
  //postdata.sector=this.addCompanyForm.get('companysector').value;
  //postdata.boardOfDirs=this.addCompanyForm.get('companyBOD').value;
  //postdata.companyDetails=this.addCompanyForm.get('companydetails').value;
  //postdata.assocStockExchange=this.addCompanyForm.get('companysesc').value;
  
  }
  public onSubmit()
  {
    //console.log(this.objpost1);
    this.addcompanyservice.postCompanies(this.company).subscribe
  (
    data=>
    {
      this.objpost=data;
    }
  );
    this._router.navigate(['getCompanies']);
  }
 
}


