import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';
import {Companies} from '../classes/companies';
@Injectable()
export class deleteCompanyService
{

    constructor(private httpclient:HttpClient){}

    public deleteCompany(companyId:number):Observable<any>
    {
        return this.httpclient.delete<Companies>("http://localhost:3002/company/deletecompany/${companyId}");
    }
}