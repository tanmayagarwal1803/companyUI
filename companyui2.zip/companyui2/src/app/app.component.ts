import { Component } from '@angular/core';
import {getCompanyService} from './services/getCompany.service';
import {Companies} from './classes/companies';
import{addCompanyService} from './services/addCompany.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
}
