import { Component, OnInit } from '@angular/core';
import {Companies} from '../classes/companies';
import{updateCompanyService} from '../services/updateCompany.service';
//import { FormGroup, FormControl, FormArray, Validators } from '@angular/forms';
//import { FormBuilder } from '@angular/forms';
import {Router} from '@angular/router';
import{ActivatedRoute} from '@angular/router';
import { getOneCompanyService } from '../services/getOneCompany.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';


@Component({
  selector: 'app-updatecompany',
  templateUrl: './updatecompany.component.html',
  styleUrls: ['./updatecompany.component.css']
})
export class UpdatecompanyComponent implements OnInit {
  company:Companies;
  findcompany:Companies;
  objupdate:Companies;
  constructor(private getonecompanyservice:getOneCompanyService,private updatecompanyservice:updateCompanyService,private _router: Router,private route:ActivatedRoute) 
  {
    this.company=new Companies();
    this.findcompany=new Companies();
    this.objupdate=new Companies();

   }
  
   
  //updateCompanyForm:FormGroup;
  
 ngOnInit(){
 
 this.route.paramMap.subscribe(params=>{
   const compid=+params.get('companyId')
   if(compid)
   {
     this.getCompany(compid);
   }
 })
}
public getCompany(compid:number)
{
  this.getonecompanyservice.getCompany(compid).subscribe
  (
    datasinglecomp=>
    {
      this.findcompany=datasinglecomp;
    }
  );
}


  //var updatedata=new Companies();
  //updatedata.companyId=this.updateCompanyForm.get('companyid').value;
  //updatedata.companyName=this.updateCompanyForm.get('companyname').value;
  //updatedata.companyCode=this.updateCompanyForm.get('companycode').value;
  //updatedata.ceo=this.updateCompanyForm.get('companyceo').value;
  //updatedata.sector=this.updateCompanyForm.get('companysector').value;
  //updatedata.boardOfDirs=this.updateCompanyForm.get('companyBOD').value;
  //updatedata.companyDetails=this.updateCompanyForm.get('companydetails').value;
  //updatedata.assocStockExchange=this.updateCompanyForm.get('companysesc').value;
  
  
  onSubmit()
  {
    this.updatecompanyservice.updateCompany(this.company).subscribe
  (
    data=>
    {
      this.objupdate=data;
    }
  );
    this._router.navigate(['getCompanies']);
  }

}
