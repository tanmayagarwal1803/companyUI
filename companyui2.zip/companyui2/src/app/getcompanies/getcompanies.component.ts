import { Component, OnInit } from '@angular/core';
import {getCompanyService} from '../services/getCompany.service';
import {Companies} from '../classes/companies';
import {deleteCompanyService} from '../services/deleteCompany.service';
import {Router} from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';

@Component({
  selector: 'app-getcompanies',
  templateUrl: './getcompanies.component.html',
  styleUrls: ['./getcompanies.component.css']
})
export class GetcompaniesComponent implements OnInit {
  constructor(private getcompanyservice:getCompanyService,private deleteCompanyservice:deleteCompanyService,private _router: Router)
  {}
  listcompanies:Companies;
  updateCompanybool=false;
  delcompany:String;
  delcompanybool=false;
ngOnInit()
{
  this.getcompanyservice.getCompanies().subscribe
  (
    data=>
    {
      this.listcompanies=data;
    }
  );

}
public deleteCompany(companyId:number)
{
  this.deleteCompanyservice.deleteCompany(companyId).subscribe
  (
    data=>
    {
      this.delcompany=data;
      if(this.delcompany=="Company deleted")
      {
        this.delcompanybool=true;
      }
    }
  );
}
public updateCompany(companyId:number){
  this._router.navigate(['update',companyId]);

}




}