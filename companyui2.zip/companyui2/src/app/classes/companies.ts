

export class Companies
{
 companyId:number;
 companyName:string;
 companyCode:number;
 ceo:string;
 boardOfDirs:string[];
 sector:string;
 companyDetails:string;
 assocStockExchange:string;


}
